(() => {
  const schema = window.TABLE_SCHEMA;
  let currentTable = null;
  let currentPk = null;
  let pendingDeleteId = null;
  let editingRowId = null; // null = create mode, otherwise the pk value being edited

  const navEl = document.getElementById('table-nav');
  const contentEl = document.getElementById('content');
  const titleEl = document.getElementById('current-table-label');
  const subEl = document.getElementById('current-table-sub');
  const newEntryBtn = document.getElementById('new-entry-btn');

  const panelOverlay = document.getElementById('panel-overlay');
  const formPanel = document.getElementById('form-panel');
  const entryForm = document.getElementById('entry-form');
  const formPanelTitle = document.getElementById('form-panel-title');
  const formError = document.getElementById('form-error');
  const closePanelBtn = document.getElementById('close-panel-btn');
  const cancelBtn = document.getElementById('cancel-btn');

  const confirmOverlay = document.getElementById('confirm-overlay');
  const confirmText = document.getElementById('confirm-text');
  const confirmCancel = document.getElementById('confirm-cancel');
  const confirmDelete = document.getElementById('confirm-delete');

  const toastEl = document.getElementById('toast');
  const connLed = document.getElementById('conn-led');
  const connText = document.getElementById('conn-text');
  const clockEl = document.getElementById('clock');

  // ---------------------------------------------------------------- Clock
  function tickClock() {
    const now = new Date();
    clockEl.textContent = now.toTimeString().split(' ')[0];
  }
  tickClock();
  setInterval(tickClock, 1000);

  // ---------------------------------------------------------------- Toast
  function showToast(message, type) {
    toastEl.textContent = message;
    toastEl.className = 'toast show ' + (type || '');
    setTimeout(() => { toastEl.className = 'toast'; }, 2600);
  }

  // ------------------------------------------------------------- Status
  async function refreshStatus() {
    try {
      const res = await fetch('/api/status');
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      connLed.classList.add('online');
      connText.textContent = 'DATABASE ONLINE';
      for (const [key, count] of Object.entries(data.counts)) {
        const countEl = document.querySelector(`[data-count="${key}"]`);
        if (countEl) countEl.textContent = count;
      }
    } catch (e) {
      connLed.classList.remove('online');
      connText.textContent = 'CONNECTION ERROR';
    }
  }
  refreshStatus();
  setInterval(refreshStatus, 15000);

  // --------------------------------------------------------- Nav switch
  navEl.addEventListener('click', (e) => {
    const item = e.target.closest('.nav-item');
    if (!item) return;
    selectTable(item.dataset.table);
  });

  function selectTable(key) {
    currentTable = key;
    currentPk = schema[key].pk;
    document.querySelectorAll('.nav-item').forEach(el => {
      el.classList.toggle('active', el.dataset.table === key);
    });
    titleEl.textContent = schema[key].label;
    subEl.textContent = `Live records from public.${key}`;
    newEntryBtn.disabled = false;
    loadRows();
  }

  newEntryBtn.addEventListener('click', () => openForm(null));

  // ------------------------------------------------------------- Rows
  async function loadRows() {
    contentEl.innerHTML = `<div class="empty-state"><p>Loading ${schema[currentTable].label}&hellip;</p></div>`;
    try {
      const res = await fetch(`/api/tables/${currentTable}/rows`);
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      renderTable(data);
    } catch (e) {
      contentEl.innerHTML = `<div class="empty-state"><div class="empty-glyph">&#9888;</div><p>Could not load data.</p><p class="empty-sub">${escapeHtml(e.message)}</p></div>`;
    }
    refreshStatus();
  }

  const STATUS_BADGE_MAP = {
    'active': 'green', 'working': 'green', 'resolved': 'green', 'completed': 'green', 'true': 'green',
    'faulty': 'red', 'inactive': 'red', 'high': 'red', 'false': 'neutral',
    'pending': 'amber', 'reported': 'amber', 'in progress': 'amber', 'under maintenance': 'amber', 'medium': 'amber',
    'low': 'neutral',
  };

  function badgeFor(value) {
    const key = (value || '').toLowerCase();
    return STATUS_BADGE_MAP[key] || null;
  }

  function renderTable(data) {
    if (data.rows.length === 0) {
      contentEl.innerHTML = `
        <div class="empty-state">
          <div class="empty-glyph">&#9707;</div>
          <p>No records yet in ${schema[currentTable].label}.</p>
          <p class="empty-sub">Use "New Entry" above to add the first row.</p>
        </div>`;
      return;
    }

    const cols = data.columns;
    let html = `<div class="table-meta"><span class="table-meta-count">${data.rows.length} record${data.rows.length === 1 ? '' : 's'}</span></div>`;
    html += `<div class="data-table-wrap"><table class="data-table"><thead><tr>`;
    cols.forEach(c => html += `<th>${escapeHtml(c)}</th>`);
    html += `<th></th></tr></thead><tbody>`;

    data.rows.forEach(row => {
      html += '<tr>';
      cols.forEach(c => {
        const val = row[c];
        if (val === null || val === undefined) {
          html += `<td class="col-null">&mdash;</td>`;
        } else {
          const badge = badgeFor(val);
          if (badge) {
            html += `<td><span class="badge badge--${badge}">${escapeHtml(val)}</span></td>`;
          } else {
            html += `<td>${escapeHtml(val)}</td>`;
          }
        }
      });
      html += `<td class="row-actions">
        <button class="edit-btn" data-id="${escapeHtml(row[data.pk])}">EDIT</button>
        <button class="delete-btn" data-id="${escapeHtml(row[data.pk])}">DELETE</button>
      </td>`;
      html += '</tr>';
    });
    html += '</tbody></table></div>';
    contentEl.innerHTML = html;

    contentEl.querySelectorAll('.delete-btn').forEach(btn => {
      btn.addEventListener('click', () => openConfirm(btn.dataset.id));
    });
    contentEl.querySelectorAll('.edit-btn').forEach(btn => {
      const rowData = data.rows.find(r => String(r[data.pk]) === String(btn.dataset.id));
      btn.addEventListener('click', () => openForm(rowData));
    });
  }

  function escapeHtml(str) {
    return String(str).replace(/[&<>"']/g, m => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    }[m]));
  }

  // -------------------------------------------------------- Insert form
  function openForm(existingRow) {
    const def = schema[currentTable];
    const isEdit = !!existingRow;
    editingRowId = isEdit ? existingRow[currentPk] : null;

    formPanelTitle.textContent = isEdit
      ? `Edit ${def.label.replace(/s$/, '')} #${editingRowId}`
      : `New ${def.label.replace(/s$/, '')}`;
    document.getElementById('submit-btn').textContent = isEdit ? 'Save Changes' : 'Insert Row';
    formError.textContent = '';
    entryForm.innerHTML = '';

    def.fields.forEach(field => {
      const wrap = document.createElement('div');
      wrap.className = 'field-group';

      const label = document.createElement('label');
      label.innerHTML = `${escapeHtml(field.label)}${field.required ? ' <span class="required-mark">*</span>' : ''}`;
      wrap.appendChild(label);

      const existingVal = isEdit ? existingRow[field.name] : null;

      let input;
      if (field.type === 'select') {
        input = document.createElement('select');
        const blank = document.createElement('option');
        blank.value = '';
        blank.textContent = field.required ? 'Select...' : '(none)';
        input.appendChild(blank);
        field.options.forEach(opt => {
          const o = document.createElement('option');
          o.value = opt;
          o.textContent = opt;
          if (existingVal !== null && String(existingVal).toLowerCase() === opt.toLowerCase()) {
            o.selected = true;
          }
          input.appendChild(o);
        });
      } else if (field.type === 'textarea') {
        input = document.createElement('textarea');
        if (existingVal !== null && existingVal !== undefined) input.value = existingVal;
      } else {
        input = document.createElement('input');
        input.type = field.type;
        if (field.step) input.step = field.step;
        if (existingVal !== null && existingVal !== undefined) input.value = existingVal;
      }
      input.name = field.name;
      if (field.required) input.required = true;
      wrap.appendChild(input);
      entryForm.appendChild(wrap);
    });

    panelOverlay.classList.add('open');
  }

  function closeForm() {
    panelOverlay.classList.remove('open');
    editingRowId = null;
  }
  closePanelBtn.addEventListener('click', closeForm);
  cancelBtn.addEventListener('click', closeForm);
  panelOverlay.addEventListener('click', (e) => { if (e.target === panelOverlay) closeForm(); });

  entryForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    formError.textContent = '';
    const formData = new FormData(entryForm);
    const payload = {};
    formData.forEach((v, k) => { payload[k] = v; });

    const isEdit = editingRowId !== null;
    const url = isEdit
      ? `/api/tables/${currentTable}/rows/${editingRowId}`
      : `/api/tables/${currentTable}/rows`;
    const method = isEdit ? 'PUT' : 'POST';

    try {
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      closeForm();
      showToast(isEdit ? 'Row updated successfully' : 'Row inserted successfully', 'success');
      loadRows();
    } catch (err) {
      formError.textContent = err.message;
    }
  });

  // ------------------------------------------------------------- Delete
  function openConfirm(id) {
    pendingDeleteId = id;
    confirmText.textContent = `This will permanently delete ${currentPk} = ${id} from ${schema[currentTable].label}. Related rows in other tables may also be removed.`;
    confirmOverlay.classList.add('open');
  }
  function closeConfirm() {
    confirmOverlay.classList.remove('open');
    pendingDeleteId = null;
  }
  confirmCancel.addEventListener('click', closeConfirm);
  confirmOverlay.addEventListener('click', (e) => { if (e.target === confirmOverlay) closeConfirm(); });

  confirmDelete.addEventListener('click', async () => {
    if (!pendingDeleteId) return;
    try {
      const res = await fetch(`/api/tables/${currentTable}/rows/${pendingDeleteId}`, { method: 'DELETE' });
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      showToast('Row deleted', 'success');
      closeConfirm();
      loadRows();
    } catch (err) {
      showToast(err.message, 'error');
      closeConfirm();
    }
  });

  // ------------------------------------------------------------ Init
  const firstKey = Object.keys(schema)[0];
  selectTable(firstKey);
})();
