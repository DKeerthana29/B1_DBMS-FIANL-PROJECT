-- [2026-08-17 11:54:34] SELECT from intersections (via Web UI)
SELECT * FROM "intersections" ORDER BY "intersection_id";

-- [2026-08-17 11:54:39] DELETE from intersections (via Web UI)
DELETE FROM "intersections" WHERE "intersection_id" = '4' RETURNING *;

-- [2026-08-17 11:54:40] SELECT from intersections (via Web UI)
SELECT * FROM "intersections" ORDER BY "intersection_id";

-- [2026-08-17 11:54:47] INSERT into intersections (via Web UI)
INSERT INTO "intersections" ("intersection_name", "road_id") VALUES ('KFB', '2') RETURNING *;

-- [2026-08-17 11:54:47] SELECT from intersections (via Web UI)
SELECT * FROM "intersections" ORDER BY "intersection_id";

-- [2026-08-17 15:35:22] SELECT from intersections (via Web UI)
SELECT * FROM "intersections" ORDER BY "intersection_id";

-- [2026-08-17 15:35:39] SELECT from trafficincidents (via Web UI)
SELECT * FROM "trafficincidents" ORDER BY "incident_id";

-- [2026-08-17 15:35:49] SELECT from maintenancerequests (via Web UI)
SELECT * FROM "maintenancerequests" ORDER BY "request_id";

-- [2026-08-17 15:36:09] INSERT into maintenancerequests (via Web UI)
INSERT INTO "maintenancerequests" ("asset_type", "asset_id", "description", "status") VALUES ('TrafficSignal', '3', 'Slow light', 'Pending') RETURNING *;

-- [2026-08-17 15:36:09] SELECT from maintenancerequests (via Web UI)
SELECT * FROM "maintenancerequests" ORDER BY "request_id";

-- [2026-08-17 16:50:18] SELECT from intersections (via Web UI)
SELECT * FROM "intersections" ORDER BY "intersection_id";

-- [2026-08-17 16:51:47] SELECT from parkinglots (via Web UI)
SELECT * FROM "parkinglots" ORDER BY "lot_id";

-- [2026-08-17 16:52:02] INSERT into parkinglots (via Web UI)
INSERT INTO "parkinglots" ("lot_name", "zone", "total_slots", "available_slots") VALUES ('GM', 'Central', '78', '12') RETURNING *;

-- [2026-08-17 16:52:02] SELECT from parkinglots (via Web UI)
SELECT * FROM "parkinglots" ORDER BY "lot_id";

-- [2026-08-17 22:07:56] SELECT from intersections (via Web UI)
SELECT * FROM "intersections" ORDER BY "intersection_id";

-- [2026-08-17 22:08:14] SELECT from roads (via Web UI)
SELECT * FROM "roads" ORDER BY "road_id";

-- [2026-08-17 22:08:26] DELETE from roads (via Web UI)
DELETE FROM "roads" WHERE "road_id" = '6' RETURNING *;

-- [2026-08-17 22:08:26] SELECT from roads (via Web UI)
SELECT * FROM "roads" ORDER BY "road_id";

-- [2026-08-17 22:09:09] SELECT from trafficsignals (via Web UI)
SELECT * FROM "trafficsignals" ORDER BY "signal_id";

-- [2026-08-17 22:09:42] INSERT into trafficsignals (via Web UI)
INSERT INTO "trafficsignals" ("intersection_id", "signal_status", "last_maintained") VALUES ('2', 'Working', '2009-08-31') RETURNING *;

-- [2026-08-18 08:46:40] SELECT from intersections (via Web UI)
SELECT * FROM "intersections" ORDER BY "intersection_id";

-- [2026-08-18 08:47:02] SELECT from trafficsignals (via Web UI)
SELECT * FROM "trafficsignals" ORDER BY "signal_id";

-- [2026-08-18 08:47:20] SELECT from sensors (via Web UI)
SELECT * FROM "sensors" ORDER BY "sensor_id";

-- [2026-08-18 08:47:21] SELECT from roads (via Web UI)
SELECT * FROM "roads" ORDER BY "road_id";

-- [2026-08-18 08:47:23] SELECT from parkinglots (via Web UI)
SELECT * FROM "parkinglots" ORDER BY "lot_id";

-- [2026-08-18 08:47:25] SELECT from intersections (via Web UI)
SELECT * FROM "intersections" ORDER BY "intersection_id";

-- [2026-08-18 08:47:26] SELECT from parkinglots (via Web UI)
SELECT * FROM "parkinglots" ORDER BY "lot_id";

-- [2026-08-18 08:47:29] SELECT from sensors (via Web UI)
SELECT * FROM "sensors" ORDER BY "sensor_id";

-- [2026-08-18 08:47:30] SELECT from trafficsignals (via Web UI)
SELECT * FROM "trafficsignals" ORDER BY "signal_id";

-- [2026-08-18 09:11:58] SELECT from intersections (via Web UI)
SELECT * FROM "intersections" ORDER BY "intersection_id";

-- [2026-08-18 09:12:09] SELECT from roads (via Web UI)
SELECT * FROM "roads" ORDER BY "road_id";

-- [2026-08-18 09:12:22] SELECT from intersections (via Web UI)
SELECT * FROM "intersections" ORDER BY "intersection_id";

-- [2026-08-18 09:12:28] SELECT from parkinglots (via Web UI)
SELECT * FROM "parkinglots" ORDER BY "lot_id";

-- [2026-08-18 09:12:49] SELECT from sensors (via Web UI)
SELECT * FROM "sensors" ORDER BY "sensor_id";

-- [2026-08-18 09:12:55] SELECT from roads (via Web UI)
SELECT * FROM "roads" ORDER BY "road_id";

-- [2026-08-18 09:13:01] SELECT from vehicles (via Web UI)
SELECT * FROM "vehicles" ORDER BY "vehicle_id";

-- [2026-08-18 09:13:08] SELECT from trafficincidents (via Web UI)
SELECT * FROM "trafficincidents" ORDER BY "incident_id";

-- [2026-08-18 09:13:12] SELECT from maintenancerequests (via Web UI)
SELECT * FROM "maintenancerequests" ORDER BY "request_id";

-- [2026-08-18 09:13:14] SELECT from vehicles (via Web UI)
SELECT * FROM "vehicles" ORDER BY "vehicle_id";

-- [2026-08-18 09:13:20] SELECT from trafficincidents (via Web UI)
SELECT * FROM "trafficincidents" ORDER BY "incident_id";

-- [2026-08-18 09:13:33] SELECT from trafficsignals (via Web UI)
SELECT * FROM "trafficsignals" ORDER BY "signal_id";

-- [2026-08-18 09:13:38] SELECT from vehicles (via Web UI)
SELECT * FROM "vehicles" ORDER BY "vehicle_id";

-- [2026-08-18 09:13:44] SELECT from trafficincidents (via Web UI)
SELECT * FROM "trafficincidents" ORDER BY "incident_id";

-- [2026-08-18 09:13:52] SELECT from parkinglots (via Web UI)
SELECT * FROM "parkinglots" ORDER BY "lot_id";

-- [2026-08-18 09:13:58] SELECT from intersections (via Web UI)
SELECT * FROM "intersections" ORDER BY "intersection_id";

-- [2026-08-18 09:14:05] SELECT from parkinglots (via Web UI)
SELECT * FROM "parkinglots" ORDER BY "lot_id";

-- [2026-08-18 09:14:13] SELECT from roads (via Web UI)
SELECT * FROM "roads" ORDER BY "road_id";

-- [2026-08-18 09:14:16] SELECT from intersections (via Web UI)
SELECT * FROM "intersections" ORDER BY "intersection_id";

-- [2026-08-18 09:14:22] SELECT from parkinglots (via Web UI)
SELECT * FROM "parkinglots" ORDER BY "lot_id";

-- [2026-08-18 09:14:33] SELECT from sensors (via Web UI)
SELECT * FROM "sensors" ORDER BY "sensor_id";

-- [2026-08-18 09:14:38] SELECT from trafficsignals (via Web UI)
SELECT * FROM "trafficsignals" ORDER BY "signal_id";

-- [2026-08-18 09:14:47] SELECT from vehicles (via Web UI)
SELECT * FROM "vehicles" ORDER BY "vehicle_id";

-- [2026-08-18 09:14:59] SELECT from trafficincidents (via Web UI)
SELECT * FROM "trafficincidents" ORDER BY "incident_id";

-- [2026-08-18 09:28:24] SELECT from roads (via Web UI)
SELECT * FROM "roads" ORDER BY "road_id";

-- [2026-09-23 09:56:29] SELECT from intersections (via Web UI)
SELECT * FROM "intersections" ORDER BY "intersection_id";

-- [2026-09-23 09:58:09] SELECT from intersections (via Web UI)
SELECT * FROM "intersections" ORDER BY "intersection_id";

-- [2026-09-23 09:58:17] SELECT from maintenancerequests (via Web UI)
SELECT * FROM "maintenancerequests" ORDER BY "request_id";

-- [2026-09-23 09:58:22] SELECT from parkinglots (via Web UI)
SELECT * FROM "parkinglots" ORDER BY "lot_id";

-- [2026-09-23 09:58:23] SELECT from sensors (via Web UI)
SELECT * FROM "sensors" ORDER BY "sensor_id";

-- [2026-09-23 09:58:24] SELECT from roads (via Web UI)
SELECT * FROM "roads" ORDER BY "road_id";

-- [2026-09-23 09:58:25] SELECT from trafficincidents (via Web UI)
SELECT * FROM "trafficincidents" ORDER BY "incident_id";

-- [2026-09-23 18:27:06] SELECT from roads (via Web UI)
SELECT * FROM "roads" ORDER BY "road_id";

-- [2026-09-23 18:27:06] SELECT from trafficsignals (via Web UI)
SELECT * FROM "trafficsignals" ORDER BY "signal_id";

-- [2026-09-23 18:27:06] SELECT from trafficincidents (via Web UI)
SELECT * FROM "trafficincidents" ORDER BY "incident_id";

-- [2026-09-23 18:27:06] SELECT from parkinglots (via Web UI)
SELECT * FROM "parkinglots" ORDER BY "lot_id";

-- [2026-09-23 18:27:06] SELECT from sensors (via Web UI)
SELECT * FROM "sensors" ORDER BY "sensor_id";

-- [2026-09-23 18:27:27] SELECT from intersections (via Web UI)
SELECT * FROM "intersections" ORDER BY "intersection_id";

-- [2026-09-23 18:27:28] SELECT from maintenancerequests (via Web UI)
SELECT * FROM "maintenancerequests" ORDER BY "request_id";

-- [2026-09-23 18:27:30] SELECT from parkinglots (via Web UI)
SELECT * FROM "parkinglots" ORDER BY "lot_id";

-- [2026-09-23 18:27:31] SELECT from roads (via Web UI)
SELECT * FROM "roads" ORDER BY "road_id";

-- [2026-09-23 18:27:33] SELECT from sensors (via Web UI)
SELECT * FROM "sensors" ORDER BY "sensor_id";

-- [2026-09-23 18:27:34] SELECT from trafficincidents (via Web UI)
SELECT * FROM "trafficincidents" ORDER BY "incident_id";

-- [2026-09-23 18:27:35] SELECT from trafficsignals (via Web UI)
SELECT * FROM "trafficsignals" ORDER BY "signal_id";

-- [2026-09-23 18:27:37] SELECT from vehicles (via Web UI)
SELECT * FROM "vehicles" ORDER BY "vehicle_id";

-- [2026-09-23 18:27:39] SELECT from roads (via Web UI)
SELECT * FROM "roads" ORDER BY "road_id";

-- [2026-09-23 18:27:39] SELECT from trafficincidents (via Web UI)
SELECT * FROM "trafficincidents" ORDER BY "incident_id";

-- [2026-09-23 18:27:39] SELECT from parkinglots (via Web UI)
SELECT * FROM "parkinglots" ORDER BY "lot_id";

-- [2026-09-23 18:27:39] SELECT from trafficsignals (via Web UI)
SELECT * FROM "trafficsignals" ORDER BY "signal_id";

-- [2026-09-23 18:28:04] SELECT from roads (via Web UI)
SELECT * FROM "roads" ORDER BY "road_id";

-- [2026-09-23 18:28:04] SELECT from trafficincidents (via Web UI)
SELECT * FROM "trafficincidents" ORDER BY "incident_id";

-- [2026-09-23 18:28:04] SELECT from parkinglots (via Web UI)
SELECT * FROM "parkinglots" ORDER BY "lot_id";

-- [2026-09-23 18:28:04] SELECT from sensors (via Web UI)
SELECT * FROM "sensors" ORDER BY "sensor_id";

-- [2026-09-23 18:28:04] SELECT from trafficsignals (via Web UI)
SELECT * FROM "trafficsignals" ORDER BY "signal_id";

-- [2026-09-23 18:28:08] SELECT from intersections (via Web UI)
SELECT * FROM "intersections" ORDER BY "intersection_id";

-- [2026-09-23 18:28:09] SELECT from maintenancerequests (via Web UI)
SELECT * FROM "maintenancerequests" ORDER BY "request_id";

-- [2026-09-23 18:36:20] SELECT from roads (via Web UI)
SELECT * FROM "roads" ORDER BY "road_id";

-- [2026-09-23 18:36:20] SELECT from trafficincidents (via Web UI)
SELECT * FROM "trafficincidents" ORDER BY "incident_id";

-- [2026-09-23 18:36:20] SELECT from parkinglots (via Web UI)
SELECT * FROM "parkinglots" ORDER BY "lot_id";

-- [2026-09-23 18:36:20] SELECT from trafficsignals (via Web UI)
SELECT * FROM "trafficsignals" ORDER BY "signal_id";

-- [2026-09-23 18:36:25] SELECT from roads (via Web UI)
SELECT * FROM "roads" ORDER BY "road_id";

-- [2026-09-23 18:36:25] SELECT from trafficincidents (via Web UI)
SELECT * FROM "trafficincidents" ORDER BY "incident_id";

-- [2026-09-23 18:37:51] SELECT from roads (via Web UI)
SELECT * FROM "roads" ORDER BY "road_id";

-- [2026-09-23 18:37:51] SELECT from trafficincidents (via Web UI)
SELECT * FROM "trafficincidents" ORDER BY "incident_id";

-- [2026-09-23 18:37:51] SELECT from parkinglots (via Web UI)
SELECT * FROM "parkinglots" ORDER BY "lot_id";

-- [2026-09-23 18:37:51] SELECT from sensors (via Web UI)
SELECT * FROM "sensors" ORDER BY "sensor_id";

-- [2026-09-23 18:37:51] SELECT from trafficsignals (via Web UI)
SELECT * FROM "trafficsignals" ORDER BY "signal_id";

-- [2026-09-23 18:37:55] SELECT from roads (via Web UI)
SELECT * FROM "roads" ORDER BY "road_id";

-- [2026-09-23 18:37:55] SELECT from trafficincidents (via Web UI)
SELECT * FROM "trafficincidents" ORDER BY "incident_id";

-- [2026-09-23 18:37:59] SELECT from roads (via Web UI)
SELECT * FROM "roads" ORDER BY "road_id";

-- [2026-09-23 18:37:59] SELECT from trafficincidents (via Web UI)
SELECT * FROM "trafficincidents" ORDER BY "incident_id";

-- [2026-09-23 18:37:59] SELECT from parkinglots (via Web UI)
SELECT * FROM "parkinglots" ORDER BY "lot_id";

-- [2026-09-23 18:37:59] SELECT from sensors (via Web UI)
SELECT * FROM "sensors" ORDER BY "sensor_id";

-- [2026-09-23 18:37:59] SELECT from trafficsignals (via Web UI)
SELECT * FROM "trafficsignals" ORDER BY "signal_id";

-- [2026-10-06 14:54:22] SELECT from parkinglots (via Web UI)
SELECT * FROM "parkinglots" ORDER BY "lot_id";

-- [2026-10-06 14:54:22] SELECT from trafficsignals (via Web UI)
SELECT * FROM "trafficsignals" ORDER BY "signal_id";

-- [2026-10-06 14:54:22] SELECT from sensors (via Web UI)
SELECT * FROM "sensors" ORDER BY "sensor_id";

-- [2026-10-06 14:54:22] SELECT from roads (via Web UI)
SELECT * FROM "roads" ORDER BY "road_id";

-- [2026-10-06 14:54:22] SELECT from trafficincidents (via Web UI)
SELECT * FROM "trafficincidents" ORDER BY "incident_id";

-- [2026-10-06 14:54:41] SELECT from roads (via Web UI)
SELECT * FROM "roads" ORDER BY "road_id";

-- [2026-10-06 14:54:41] SELECT from trafficincidents (via Web UI)
SELECT * FROM "trafficincidents" ORDER BY "incident_id";

-- [2026-10-06 14:54:51] SELECT from maintenancerequests (via Web UI)
SELECT * FROM "maintenancerequests" ORDER BY "request_id";

-- [2026-10-06 14:54:57] SELECT from intersections (via Web UI)
SELECT * FROM "intersections" ORDER BY "intersection_id";

-- [2026-10-06 14:55:12] SELECT from trafficincidents (via Web UI)
SELECT * FROM "trafficincidents" ORDER BY "incident_id";

-- [2026-10-06 14:55:12] SELECT from parkinglots (via Web UI)
SELECT * FROM "parkinglots" ORDER BY "lot_id";

-- [2026-10-06 14:55:12] SELECT from sensors (via Web UI)
SELECT * FROM "sensors" ORDER BY "sensor_id";

-- [2026-10-06 14:55:12] SELECT from trafficsignals (via Web UI)
SELECT * FROM "trafficsignals" ORDER BY "signal_id";

-- [2026-10-06 14:55:12] SELECT from roads (via Web UI)
SELECT * FROM "roads" ORDER BY "road_id";

-- [2026-10-06 14:55:21] SELECT from parkinglots (via Web UI)
SELECT * FROM "parkinglots" ORDER BY "lot_id";

-- [2026-10-16 18:43:32] SELECT from roads (via Web UI)
SELECT * FROM "roads" ORDER BY "road_id";

-- [2026-10-16 18:43:32] SELECT from trafficincidents (via Web UI)
SELECT * FROM "trafficincidents" ORDER BY "incident_id";

-- [2026-10-16 18:43:32] SELECT from parkinglots (via Web UI)
SELECT * FROM "parkinglots" ORDER BY "lot_id";

-- [2026-10-16 18:43:32] SELECT from sensors (via Web UI)
SELECT * FROM "sensors" ORDER BY "sensor_id";

-- [2026-10-16 18:43:32] SELECT from trafficsignals (via Web UI)
SELECT * FROM "trafficsignals" ORDER BY "signal_id";

-- [2026-10-16 18:43:41] SELECT from roads (via Web UI)
SELECT * FROM "roads" ORDER BY "road_id";

-- [2026-10-16 18:43:42] SELECT from trafficincidents (via Web UI)
SELECT * FROM "trafficincidents" ORDER BY "incident_id";

-- [2026-10-16 18:43:44] SELECT from intersections (via Web UI)
SELECT * FROM "intersections" ORDER BY "intersection_id";

-- [2026-10-16 18:44:02] INSERT into intersections (via Web UI)
INSERT INTO "intersections" ("intersection_name", "road_id", "has_signal") VALUES ('KFG', '1', 'true') RETURNING *;

-- [2026-10-16 18:44:02] SELECT from intersections (via Web UI)
SELECT * FROM "intersections" ORDER BY "intersection_id";

-- [2026-10-16 18:44:05] SELECT from maintenancerequests (via Web UI)
SELECT * FROM "maintenancerequests" ORDER BY "request_id";

-- [2026-10-16 18:44:41] INSERT into maintenancerequests (via Web UI)
INSERT INTO "maintenancerequests" ("asset_type", "asset_id", "description", "status") VALUES ('Road', '1', 'NONE', 'In Progress') RETURNING *;

-- [2026-10-16 18:44:41] SELECT from maintenancerequests (via Web UI)
SELECT * FROM "maintenancerequests" ORDER BY "request_id";

-- [2026-10-16 18:46:47] DELETE from maintenancerequests (via Web UI)
DELETE FROM "maintenancerequests" WHERE "request_id" = '5' RETURNING *;

-- [2026-10-16 18:46:47] SELECT from maintenancerequests (via Web UI)
SELECT * FROM "maintenancerequests" ORDER BY "request_id";

-- [2026-10-16 18:46:51] DELETE from maintenancerequests (via Web UI)
DELETE FROM "maintenancerequests" WHERE "request_id" = '3' RETURNING *;

-- [2026-10-16 18:46:51] SELECT from maintenancerequests (via Web UI)
SELECT * FROM "maintenancerequests" ORDER BY "request_id";

-- [2026-10-16 18:46:52] SELECT from roads (via Web UI)
SELECT * FROM "roads" ORDER BY "road_id";

-- [2026-10-16 18:46:56] DELETE from roads (via Web UI)
DELETE FROM "roads" WHERE "road_id" = '8' RETURNING *;

-- [2026-10-16 18:46:56] SELECT from roads (via Web UI)
SELECT * FROM "roads" ORDER BY "road_id";

-- [2026-10-16 18:46:59] DELETE from roads (via Web UI)
DELETE FROM "roads" WHERE "road_id" = '3' RETURNING *;

-- [2026-10-16 18:46:59] SELECT from roads (via Web UI)
SELECT * FROM "roads" ORDER BY "road_id";

-- [2026-10-16 21:09:46] SELECT from trafficincidents (via Web UI)
SELECT * FROM "trafficincidents" ORDER BY "incident_id";

-- [2026-10-16 21:09:46] SELECT from roads (via Web UI)
SELECT * FROM "roads" ORDER BY "road_id";

-- [2026-10-16 21:09:46] SELECT from parkinglots (via Web UI)
SELECT * FROM "parkinglots" ORDER BY "lot_id";

-- [2026-10-16 21:09:46] SELECT from sensors (via Web UI)
SELECT * FROM "sensors" ORDER BY "sensor_id";

-- [2026-10-16 21:09:46] SELECT from trafficsignals (via Web UI)
SELECT * FROM "trafficsignals" ORDER BY "signal_id";

-- [2026-10-16 21:09:58] SELECT from roads (via Web UI)
SELECT * FROM "roads" ORDER BY "road_id";

-- [2026-10-16 21:09:58] SELECT from trafficincidents (via Web UI)
SELECT * FROM "trafficincidents" ORDER BY "incident_id";

-- [2026-10-16 21:10:00] SELECT from intersections (via Web UI)
SELECT * FROM "intersections" ORDER BY "intersection_id";

-- [2026-10-16 21:10:21] SELECT from roads (via Web UI)
SELECT * FROM "roads" ORDER BY "road_id";

-- [2026-10-16 21:10:21] SELECT from trafficincidents (via Web UI)
SELECT * FROM "trafficincidents" ORDER BY "incident_id";

-- [2026-10-16 21:10:21] SELECT from parkinglots (via Web UI)
SELECT * FROM "parkinglots" ORDER BY "lot_id";

-- [2026-10-16 21:10:21] SELECT from trafficsignals (via Web UI)
SELECT * FROM "trafficsignals" ORDER BY "signal_id";

-- [2026-10-16 21:10:25] SELECT from roads (via Web UI)
SELECT * FROM "roads" ORDER BY "road_id";

-- [2026-10-16 21:10:25] SELECT from trafficincidents (via Web UI)
SELECT * FROM "trafficincidents" ORDER BY "incident_id";

-- [2026-10-16 21:10:26] SELECT from intersections (via Web UI)
SELECT * FROM "intersections" ORDER BY "intersection_id";

-- [2026-10-16 21:43:46] SELECT from roads (via Web UI)
SELECT * FROM "roads" ORDER BY "road_id";

-- [2026-10-16 21:43:46] SELECT from trafficincidents (via Web UI)
SELECT * FROM "trafficincidents" ORDER BY "incident_id";

-- [2026-10-16 21:43:46] SELECT from parkinglots (via Web UI)
SELECT * FROM "parkinglots" ORDER BY "lot_id";

-- [2026-10-16 21:43:46] SELECT from sensors (via Web UI)
SELECT * FROM "sensors" ORDER BY "sensor_id";

-- [2026-10-16 21:43:46] SELECT from trafficsignals (via Web UI)
SELECT * FROM "trafficsignals" ORDER BY "signal_id";

-- [2026-10-16 21:44:01] SELECT from roads (via Web UI)
SELECT * FROM "roads" ORDER BY "road_id";

-- [2026-10-16 21:44:01] SELECT from trafficincidents (via Web UI)
SELECT * FROM "trafficincidents" ORDER BY "incident_id";

-- [2026-10-16 21:44:03] SELECT from intersections (via Web UI)
SELECT * FROM "intersections" ORDER BY "intersection_id";

-- [2026-10-16 21:44:22] SELECT from roads (via Web UI)
SELECT * FROM "roads" ORDER BY "road_id";

-- [2026-10-16 21:44:22] SELECT from trafficincidents (via Web UI)
SELECT * FROM "trafficincidents" ORDER BY "incident_id";

-- [2026-10-16 21:44:22] SELECT from parkinglots (via Web UI)
SELECT * FROM "parkinglots" ORDER BY "lot_id";

-- [2026-10-16 21:44:22] SELECT from sensors (via Web UI)
SELECT * FROM "sensors" ORDER BY "sensor_id";

-- [2026-10-16 21:44:22] SELECT from trafficsignals (via Web UI)
SELECT * FROM "trafficsignals" ORDER BY "signal_id";

-- [2026-10-16 21:44:25] SELECT from intersections (via Web UI)
SELECT * FROM "intersections" ORDER BY "intersection_id";

-- [2026-10-16 21:45:00] SELECT from roads (via Web UI)
SELECT * FROM "roads" ORDER BY "road_id";

-- [2026-10-16 21:45:00] SELECT from parkinglots (via Web UI)
SELECT * FROM "parkinglots" ORDER BY "lot_id";

cident_id";

-- [2026-10-16 21:45:00] SELECT from sensors (via Web UI)
SELECT * FROM "sensors" ORDER BY "sensor_id";

-- [2026-10-16 21:45:00] SELECT from trafficsignals (via Web UI)
SELECT * FROM "trafficsignals" ORDER BY "signal_id";

-- [2026-10-16 21:45:06] SELECT from intersections (via Web UI)
SELECT * FROM "intersections" ORDER BY "intersection_id";

-- [2026-10-16 21:45:16] DELETE from intersections (via Web UI)
DELETE FROM "intersections" WHERE "intersection_id" = '5' RETURNING *;

-- [2026-10-16 21:45:16] SELECT from intersections (via Web UI)
SELECT * FROM "intersections" ORDER BY "intersection_id";

-- [2026-10-16 21:45:55] INSERT into intersections (via Web UI)
INSERT INTO "intersections" ("intersection_name", "road_id", "has_signal") VALUES ('yty', '2', 'true') RETURNING *;

-- [2026-10-16 21:45:55] SELECT from intersections (via Web UI)
SELECT * FROM "intersections" ORDER BY "intersection_id";

-- [2026-10-16 21:51:31] SELECT from maintenancerequests (via Web UI)
SELECT * FROM "maintenancerequests" ORDER BY "request_id";

-- [2026-10-16 21:51:34] SELECT from roads (via Web UI)
SELECT * FROM "roads" ORDER BY "road_id";

-- [2026-10-16 21:51:36] SELECT from parkinglots (via Web UI)
SELECT * FROM "parkinglots" ORDER BY "lot_id";

-- [2026-10-16 21:51:38] SELECT from roads (via Web UI)
SELECT * FROM "roads" ORDER BY "road_id";

-- [2026-10-16 21:52:09] SELECT from sensors (via Web UI)
SELECT * FROM "sensors" ORDER BY "sensor_id";

-- [2026-10-16 21:52:11] SELECT from trafficincidents (via Web UI)
SELECT * FROM "trafficincidents" ORDER BY "incident_id";

-- [2026-10-16 21:52:13] SELECT from trafficsignals (via Web UI)
SELECT * FROM "trafficsignals" ORDER BY "signal_id";

-- [2026-10-16 21:52:14] SELECT from vehicles (via Web UI)
SELECT * FROM "vehicles" ORDER BY "vehicle_id";

-- [2026-10-16 21:57:46] SELECT from roads (via Web UI)
SELECT * FROM "roads" ORDER BY "road_id";

-- [2026-10-16 21:57:46] SELECT from trafficincidents (via Web UI)
SELECT * FROM "trafficincidents" ORDER BY "incident_id";

-- [2026-10-16 21:57:46] SELECT from parkinglots (via Web UI)
SELECT * FROM "parkinglots" ORDER BY "lot_id";

-- [2026-10-16 21:57:46] SELECT from sensors (via Web UI)
SELECT * FROM "sensors" ORDER BY "sensor_id";

-- [2026-10-16 21:57:46] SELECT from trafficsignals (via Web UI)
SELECT * FROM "trafficsignals" ORDER BY "signal_id";

-- [2026-10-16 21:58:06] SELECT from roads (via Web UI)
SELECT * FROM "roads" ORDER BY "road_id";

-- [2026-10-16 21:58:06] SELECT from trafficincidents (via Web UI)
SELECT * FROM "trafficincidents" ORDER BY "incident_id";

-- [2026-10-16 21:58:06] SELECT from parkinglots (via Web UI)
SELECT * FROM "parkinglots" ORDER BY "lot_id";

-- [2026-10-16 21:58:06] SELECT from sensors (via Web UI)
SELECT * FROM "sensors" ORDER BY "sensor_id";

-- [2026-10-16 21:58:06] SELECT from trafficsignals (via Web UI)
SELECT * FROM "trafficsignals" ORDER BY "signal_id";

-- [2026-10-16 21:58:50] SELECT from roads (via Web UI)
SELECT * FROM "roads" ORDER BY "road_id";

-- [2026-10-16 21:58:50] SELECT from trafficincidents (via Web UI)
SELECT * FROM "trafficincidents" ORDER BY "incident_id";

-- [2026-10-16 21:59:18] SELECT from intersections (via Web UI)
SELECT * FROM "intersections" ORDER BY "intersection_id";

