"""
Run this ONCE after creating the users table (04a_users_table.sql)
to seed two demo accounts:

    admin  / admin123   -> role 'admin'  (full CRUD access)
    viewer / viewer123  -> role 'viewer' (read-only)

Usage:
    pip install psycopg2-binary werkzeug
    python seed_users.py

Change the usernames/passwords below before your actual demo if
you want something less guessable.
"""

import psycopg2
import getpass
from werkzeug.security import generate_password_hash

DB_CONFIG = {
    "host": "localhost",
    "port": 5432,
    "dbname": "URBANSYNC",
    "user": "postgres",
}

DEMO_USERS = [
    ("admin", "admin123", "admin"),
    ("viewer", "viewer123", "viewer"),
]


def main():
    password = getpass.getpass("Enter PostgreSQL password: ")
    conn = psycopg2.connect(password=password, **DB_CONFIG)
    try:
        with conn.cursor() as cur:
            for username, plain_password, role in DEMO_USERS:
                pw_hash = generate_password_hash(plain_password)
                cur.execute(
                    """
                    INSERT INTO users (username, password_hash, role)
                    VALUES (%s, %s, %s)
                    ON CONFLICT (username) DO UPDATE
                        SET password_hash = EXCLUDED.password_hash,
                            role = EXCLUDED.role
                    """,
                    (username, pw_hash, role),
                )
        conn.commit()
        print("Seeded users:")
        for username, plain_password, role in DEMO_USERS:
            print(f"  {username} / {plain_password}  (role: {role})")
    finally:
        conn.close()


if __name__ == "__main__":
    main()
