"""
UrbanSync Control Dashboard
----------------------------
A local Flask web app providing a UI for insert / view / update / delete
operations on the UrbanSync PostgreSQL database (with connection pooling).

Setup:
    pip install flask psycopg2-binary

Run:
    python app.py

Then open http://localhost:5000 in your browser.
"""

from flask import Flask, render_template, request, jsonify, session, redirect, url_for
from functools import wraps
from werkzeug.security import check_password_hash
import psycopg2
from psycopg2 import sql, pool
import os
from datetime import datetime

app = Flask(__name__)
# Used to sign the session cookie.
# Set SECRET_KEY in the environment for stable sessions. If it is missing we
# generate a random key at startup (sessions just reset when the app restarts).
app.secret_key = os.environ.get("SECRET_KEY") or os.urandom(32).hex()

# ---------------------------------------------------------------------------
# Database configuration - update if your username differs.
# Password is read from the URBANSYNC_DB_PASSWORD environment variable if
# set; otherwise you'll be prompted in the terminal the first time it's
# needed (see get_connection below).
# ---------------------------------------------------------------------------
DB_CONFIG = {
    "host": "localhost",
    "port": 5432,
    "dbname": "URBANSYNC",
    "user": "postgres",
}

_cached_password = os.environ.get("URBANSYNC_DB_PASSWORD")

# Same log file the CLI script (urbansync_crud.py) writes to. Keep both
# tools pointed at this exact filename/location so everything - whether
# it ran from the terminal CLI or from this web dashboard - ends up in one
# combined, chronological .sql file you can open in pgAdmin's Query tab.
QUERY_LOG_FILE = "urbansync_query_log.sql"


def log_query(cur, query, values, label=""):
    """Write the final SQL (with values substituted) to QUERY_LOG_FILE."""
    try:
        final_sql = cur.mogrify(query, values).decode()
    except Exception:
        final_sql = f"-- (could not render values inline)\n-- Query: {query}\n-- Values: {values}"
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(QUERY_LOG_FILE, "a", encoding="utf-8") as f:
        if label:
            f.write(f"-- [{timestamp}] {label} (via Web UI)\n")
        else:
            f.write(f"-- [{timestamp}] (via Web UI)\n")
        f.write(final_sql.rstrip())
        if not final_sql.rstrip().endswith(";"):
            f.write(";")
        f.write("\n\n")


_pool = None


def get_connection():
    """Borrow a connection from the pool (created lazily on first use so the
    password prompt still works). Always hand it back with release_connection()."""
    global _cached_password, _pool
    if not _cached_password:
        import getpass
        _cached_password = getpass.getpass("Enter PostgreSQL password: ")
    if _pool is None:
        cfg = DB_CONFIG.copy()
        cfg["password"] = _cached_password
        try:
            _pool = pool.ThreadedConnectionPool(minconn=1, maxconn=10, **cfg)
        except psycopg2.OperationalError as e:
            # Bad password: forget it so the NEXT request re-prompts.
            if "password authentication failed" in str(e):
                _cached_password = None
            raise
    return _pool.getconn()


def release_connection(conn):
    """Return a connection to the pool (rolls back any open transaction)."""
    if _pool is not None:
        _pool.putconn(conn)
    else:
        conn.close()


# ---------------------------------------------------------------------------
# Auth: simple 2-tier role-based access (admin / viewer)
# ---------------------------------------------------------------------------

def login_required(view_func):
    @wraps(view_func)
    def wrapped(*args, **kwargs):
        if "username" not in session:
            # For page loads, send to login. For API calls, return 401 JSON
            # instead of an HTML redirect so the frontend JS can handle it.
            if request.path.startswith("/api/"):
                return jsonify({"error": "Not logged in"}), 401
            return redirect(url_for("login"))
        return view_func(*args, **kwargs)
    return wrapped


def admin_required(view_func):
    @wraps(view_func)
    def wrapped(*args, **kwargs):
        if "username" not in session:
            if request.path.startswith("/api/"):
                return jsonify({"error": "Not logged in"}), 401
            return redirect(url_for("login"))
        if session.get("role") != "admin":
            return jsonify({"error": "Admin access required"}), 403
        return view_func(*args, **kwargs)
    return wrapped


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "GET":
        return render_template("login.html", error=None)

    username = request.form.get("username", "").strip()
    password = request.form.get("password", "")

    try:
        conn = get_connection()
    except Exception:
        return render_template("login.html", error="Could not reach the database."), 500

    try:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT password_hash, role FROM users WHERE username = %s",
                (username,),
            )
            row = cur.fetchone()
    finally:
        release_connection(conn)

    if not row or not check_password_hash(row[0], password):
        return render_template("login.html", error="Invalid username or password."), 401

    session["username"] = username
    session["role"] = row[1]
    return redirect(url_for("index"))


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


# ---------------------------------------------------------------------------
# Table definitions - mirrors the actual UrbanSync schema.
# ---------------------------------------------------------------------------
TABLES = {
    "roads": {
        "label": "Roads",
        "icon": "road",
        "pk": "road_id",
        "fields": [
            {"name": "road_name", "label": "Road name", "type": "text", "required": True},
            {"name": "length_km", "label": "Length (km)", "type": "number", "step": "0.01", "required": False},
            {"name": "num_lanes", "label": "Number of lanes", "type": "number", "step": "1", "required": False},
            {"name": "zone", "label": "Zone", "type": "select",
             "options": ["Central", "North", "South", "East", "West"], "required": False},
        ],
    },
    "intersections": {
        "label": "Intersections",
        "icon": "intersection",
        "pk": "intersection_id",
        "fields": [
            {"name": "intersection_name", "label": "Intersection name", "type": "text", "required": True},
            {"name": "road_id", "label": "Road ID", "type": "number", "step": "1", "required": False},
            {"name": "has_signal", "label": "Has signal", "type": "select",
             "options": ["true", "false"], "required": False},
        ],
    },
    "parkinglots": {
        "label": "Parking Lots",
        "icon": "parking",
        "pk": "lot_id",
        "fields": [
            {"name": "lot_name", "label": "Lot name", "type": "text", "required": True},
            {"name": "zone", "label": "Zone", "type": "select",
             "options": ["Central", "North", "South", "East", "West"], "required": False},
            {"name": "total_slots", "label": "Total slots", "type": "number", "step": "1", "required": True},
            {"name": "available_slots", "label": "Available slots", "type": "number", "step": "1", "required": True},
        ],
    },
    "sensors": {
        "label": "Sensors",
        "icon": "sensor",
        "pk": "sensor_id",
        "fields": [
            {"name": "sensor_type", "label": "Sensor type", "type": "text", "required": False},
            {"name": "road_id", "label": "Road ID", "type": "number", "step": "1", "required": False},
            {"name": "status", "label": "Status", "type": "select",
             "options": ["Active", "Inactive", "Faulty"], "required": False},
        ],
    },
    "trafficsignals": {
        "label": "Traffic Signals",
        "icon": "signal",
        "pk": "signal_id",
        "fields": [
            {"name": "intersection_id", "label": "Intersection ID", "type": "number", "step": "1", "required": False},
            {"name": "signal_status", "label": "Signal status", "type": "select",
             "options": ["Working", "Faulty", "Under Maintenance"], "required": False},
            {"name": "last_maintained", "label": "Last maintained", "type": "date", "required": False},
        ],
    },
    "vehicles": {
        "label": "Vehicles",
        "icon": "vehicle",
        "pk": "vehicle_id",
        "fields": [
            {"name": "plate_number", "label": "Plate number", "type": "text", "required": True},
            {"name": "vehicle_type", "label": "Vehicle type", "type": "select",
             "options": ["Car", "Bike", "Bus", "Truck"], "required": False},
            {"name": "owner_name", "label": "Owner name", "type": "text", "required": False},
        ],
    },
    "trafficincidents": {
        "label": "Traffic Incidents",
        "icon": "incident",
        "pk": "incident_id",
        "fields": [
            {"name": "road_id", "label": "Road ID", "type": "number", "step": "1", "required": False},
            {"name": "incident_type", "label": "Incident type", "type": "text", "required": False},
            {"name": "severity", "label": "Severity", "type": "select",
             "options": ["Low", "Medium", "High"], "required": False},
            {"name": "status", "label": "Status", "type": "select",
             "options": ["Reported", "In Progress", "Resolved"], "required": False},
        ],
    },
    "maintenancerequests": {
        "label": "Maintenance Requests",
        "icon": "maintenance",
        "pk": "request_id",
        "fields": [
            {"name": "asset_type", "label": "Asset type", "type": "select",
             "options": ["Road", "Sensor", "TrafficSignal", "ParkingLot"], "required": False},
            {"name": "asset_id", "label": "Asset ID", "type": "number", "step": "1", "required": False},
            {"name": "description", "label": "Description", "type": "textarea", "required": False},
            {"name": "status", "label": "Status", "type": "select",
             "options": ["Pending", "In Progress", "Completed"], "required": False},
        ],
    },
}


def table_or_404(table_name):
    if table_name not in TABLES:
        raise ValueError(f"Unknown table: {table_name}")
    return TABLES[table_name]


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------

@app.route("/")
@login_required
def index():
    return render_template("index.html", tables=TABLES,
                            username=session.get("username"),
                            role=session.get("role"))


@app.route("/api/status")
@login_required
def api_status():
    """Row counts for every table, used for the dashboard overview strip."""
    try:
        conn = get_connection()
    except Exception as e:
        return jsonify({"error": str(e)}), 500

    counts = {}
    try:
        with conn.cursor() as cur:
            for name in TABLES:
                cur.execute(sql.SQL("SELECT COUNT(*) FROM {}").format(sql.Identifier(name)))
                counts[name] = cur.fetchone()[0]
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        release_connection(conn)

    return jsonify({"counts": counts})


@app.route("/api/tables/<table_name>/rows", methods=["GET"])
@login_required
def get_rows(table_name):
    try:
        table_def = table_or_404(table_name)
    except ValueError as e:
        return jsonify({"error": str(e)}), 404

    try:
        conn = get_connection()
    except Exception as e:
        return jsonify({"error": str(e)}), 500

    try:
        with conn.cursor() as cur:
            select_query = sql.SQL("SELECT * FROM {} ORDER BY {}").format(
                sql.Identifier(table_name), sql.Identifier(table_def["pk"])
            )
            log_query(cur, select_query, [], label=f"SELECT from {table_name}")
            cur.execute(select_query)
            rows = cur.fetchall()
            colnames = [desc[0] for desc in cur.description]
    except Exception as e:
        conn.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        release_connection(conn)

    data = [dict(zip(colnames, [str(v) if v is not None else None for v in row])) for row in rows]
    return jsonify({"columns": colnames, "rows": data, "pk": table_def["pk"]})


@app.route("/api/tables/<table_name>/rows", methods=["POST"])
@admin_required
def insert_row(table_name):
    try:
        table_def = table_or_404(table_name)
    except ValueError as e:
        return jsonify({"error": str(e)}), 404

    payload = request.get_json(force=True) or {}
    columns, values = [], []
    for field in table_def["fields"]:
        raw = payload.get(field["name"])
        if raw is not None and str(raw).strip() != "":
            columns.append(field["name"])
            values.append(raw)
        elif field["required"]:
            return jsonify({"error": f"{field['label']} is required."}), 400

    if not columns:
        return jsonify({"error": "No data provided."}), 400

    query = sql.SQL("INSERT INTO {table} ({fields}) VALUES ({placeholders}) RETURNING *").format(
        table=sql.Identifier(table_name),
        fields=sql.SQL(", ").join(map(sql.Identifier, columns)),
        placeholders=sql.SQL(", ").join(sql.Placeholder() * len(columns)),
    )

    try:
        conn = get_connection()
    except Exception as e:
        return jsonify({"error": str(e)}), 500

    try:
        with conn.cursor() as cur:
            log_query(cur, query, values, label=f"INSERT into {table_name}")
            cur.execute(query, values)
            new_row = cur.fetchone()
            colnames = [desc[0] for desc in cur.description]
            conn.commit()
    except Exception as e:
        conn.rollback()
        return jsonify({"error": str(e)}), 400
    finally:
        release_connection(conn)

    return jsonify({"row": dict(zip(colnames, [str(v) if v is not None else None for v in new_row]))})


@app.route("/api/tables/<table_name>/rows/<row_id>", methods=["PUT"])
@admin_required
def update_row(table_name, row_id):
    try:
        table_def = table_or_404(table_name)
    except ValueError as e:
        return jsonify({"error": str(e)}), 404

    payload = request.get_json(force=True) or {}
    columns, values = [], []
    for field in table_def["fields"]:
        raw = payload.get(field["name"])
        if raw is not None and str(raw).strip() != "":
            columns.append(field["name"])
            values.append(raw)
        elif field["required"]:
            return jsonify({"error": f"{field['label']} is required."}), 400

    if not columns:
        return jsonify({"error": "No data provided."}), 400

    set_clause = sql.SQL(", ").join(
        sql.SQL("{} = {}").format(sql.Identifier(c), sql.Placeholder()) for c in columns
    )
    query = sql.SQL("UPDATE {table} SET {set_clause} WHERE {pk} = %s RETURNING *").format(
        table=sql.Identifier(table_name),
        set_clause=set_clause,
        pk=sql.Identifier(table_def["pk"]),
    )

    try:
        conn = get_connection()
    except Exception as e:
        return jsonify({"error": str(e)}), 500

    try:
        with conn.cursor() as cur:
            log_query(cur, query, values + [row_id], label=f"UPDATE {table_name}")
            cur.execute(query, values + [row_id])
            updated = cur.fetchone()
            colnames = [desc[0] for desc in cur.description]
            conn.commit()
    except Exception as e:
        conn.rollback()
        return jsonify({"error": str(e)}), 400
    finally:
        release_connection(conn)

    if not updated:
        return jsonify({"error": f"No row found with {table_def['pk']} = {row_id}"}), 404

    return jsonify({"row": dict(zip(colnames, [str(v) if v is not None else None for v in updated]))})


@app.route("/api/tables/<table_name>/rows/<row_id>", methods=["DELETE"])
@admin_required
def delete_row(table_name, row_id):
    try:
        table_def = table_or_404(table_name)
    except ValueError as e:
        return jsonify({"error": str(e)}), 404

    query = sql.SQL("DELETE FROM {table} WHERE {pk} = %s RETURNING *").format(
        table=sql.Identifier(table_name),
        pk=sql.Identifier(table_def["pk"]),
    )

    try:
        conn = get_connection()
    except Exception as e:
        return jsonify({"error": str(e)}), 500

    try:
        with conn.cursor() as cur:
            log_query(cur, query, (row_id,), label=f"DELETE from {table_name}")
            cur.execute(query, (row_id,))
            deleted = cur.fetchone()
            conn.commit()
    except Exception as e:
        conn.rollback()
        return jsonify({"error": str(e)}), 400
    finally:
        release_connection(conn)

    if not deleted:
        return jsonify({"error": f"No row found with {table_def['pk']} = {row_id}"}), 404
    return jsonify({"deleted": True})


if __name__ == "__main__":
    if not _cached_password:
        print(
            "NOTE: No URBANSYNC_DB_PASSWORD environment variable found.\n"
            "      You'll be prompted for the Postgres password once below.\n"
            "      (To skip this prompt next time, set the env var instead.)\n"
        )
        import getpass
        _cached_password = getpass.getpass("Enter PostgreSQL password: ")

    print("Starting UrbanSync Control Dashboard at http://localhost:5000")
    # debug=False: debug mode exposes an interactive console that can run
    # arbitrary code if anyone reaches it — fine for local dev, not for
    # anything you'd show in a review or leave running.
    # use_reloader=False: with the reloader on, Flask launches a second
    # background process, and both processes fight over terminal input,
    # which is what corrupted the password prompt earlier.
    app.run(debug=False, port=5000, use_reloader=False)