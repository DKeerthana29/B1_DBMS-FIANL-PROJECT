"""
UrbanSync - Interactive CRUD CLI
----------------------------------
Pick a table, then choose to Insert, View, Update, or Delete rows.

Requirements:
    pip install psycopg2-binary
"""

import psycopg2
from psycopg2 import sql
from datetime import datetime

DB_CONFIG = {
    "host": "localhost",
    "port": 5432,
    "dbname": "URBANSYNC",
    "user": "postgres",
    "password": None,   # will be asked at runtime if left as None
}

# Every INSERT / UPDATE / DELETE the script runs gets appended here as
# plain, ready-to-run SQL (with values already filled in). Open this file
# in pgAdmin's Query tab any time to see / show / re-run exactly what the
# CLI did.
QUERY_LOG_FILE = "urbansync_query_log.sql"


def log_query(conn, cur, query, values, label=""):
    """Write the final SQL (with values substituted) to QUERY_LOG_FILE."""
    try:
        final_sql = cur.mogrify(query, values).decode()
    except Exception:
        # mogrify can fail on some param combos (e.g. named placeholders);
        # fall back to logging the raw query + values instead of crashing.
        final_sql = f"-- (could not render values inline)\n-- Query: {query}\n-- Values: {values}"
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(QUERY_LOG_FILE, "a", encoding="utf-8") as f:
        if label:
            f.write(f"-- [{timestamp}] {label}\n")
        else:
            f.write(f"-- [{timestamp}]\n")
        f.write(final_sql.rstrip())
        if not final_sql.rstrip().endswith(";"):
            f.write(";")
        f.write("\n\n")


def _bool_caster(val):
    v = val.strip().lower()
    if v in ("true", "t", "yes", "y", "1"):
        return True
    if v in ("false", "f", "no", "n", "0"):
        return False
    raise ValueError("expected true/false")


def _date_caster(val):
    return datetime.strptime(val.strip(), "%Y-%m-%d").date()


# Each table maps to: display name, its primary key column, and its fields
# Field tuple: (column_name, prompt_text, required, caster_function)
TABLES = {
    "1": {
        "name": "roads",
        "label": "Roads",
        "pk": "road_id",
        "fields": [
            ("road_name", "Road name", True, str),
            ("length_km", "Length in km (e.g. 3.5)", False, float),
            ("num_lanes", "Number of lanes (integer)", False, int),
            ("zone", "Zone (e.g. Central/North/South/East/West)", False, str),
        ],
    },
    "2": {
        "name": "intersections",
        "label": "Intersections",
        "pk": "intersection_id",
        "fields": [
            ("intersection_name", "Intersection name", True, str),
            ("road_id", "Road ID (must exist in roads table)", False, int),
            ("has_signal", "Has signal? (true/false)", False, _bool_caster),
        ],
    },
    "3": {
        "name": "parkinglots",
        "label": "Parking Lots",
        "pk": "lot_id",
        "fields": [
            ("lot_name", "Parking lot name", True, str),
            ("zone", "Zone", False, str),
            ("total_slots", "Total slots (integer)", True, int),
            ("available_slots", "Available slots (integer)", True, int),
        ],
    },
    "4": {
        "name": "sensors",
        "label": "Sensors",
        "pk": "sensor_id",
        "fields": [
            ("sensor_type", "Sensor type (e.g. Traffic Camera, Speed Sensor)", False, str),
            ("road_id", "Road ID (must exist in roads table)", False, int),
            ("status", "Status (Active / Inactive / Faulty)", False, str),
        ],
    },
    "5": {
        "name": "trafficsignals",
        "label": "Traffic Signals",
        "pk": "signal_id",
        "fields": [
            ("intersection_id", "Intersection ID (must exist in intersections table)", False, int),
            ("signal_status", "Signal status (Working / Faulty / Under Maintenance)", False, str),
            ("last_maintained", "Last maintained date (YYYY-MM-DD)", False, _date_caster),
        ],
    },
    "6": {
        "name": "vehicles",
        "label": "Vehicles",
        "pk": "vehicle_id",
        "fields": [
            ("plate_number", "Plate number (must be unique)", True, str),
            ("vehicle_type", "Vehicle type (Car/Bike/Bus/Truck)", False, str),
            ("owner_name", "Owner name", False, str),
        ],
    },
    "7": {
        "name": "trafficincidents",
        "label": "Traffic Incidents",
        "pk": "incident_id",
        "fields": [
            ("road_id", "Road ID (must exist in roads table)", False, int),
            ("incident_type", "Incident type (e.g. Accident, Pothole, Congestion)", False, str),
            ("severity", "Severity (Low / Medium / High)", False, str),
            ("status", "Status (Reported / In Progress / Resolved)", False, str),
        ],
    },
    "8": {
        "name": "maintenancerequests",
        "label": "Maintenance Requests",
        "pk": "request_id",
        "fields": [
            ("asset_type", "Asset type (e.g. Road, Sensor, TrafficSignal, ParkingLot)", False, str),
            ("asset_id", "Asset ID (ID of that asset in its own table)", False, int),
            ("description", "Description of the issue", False, str),
            ("status", "Status (Pending / In Progress / Completed)", False, str),
        ],
    },
}


def connect():
    cfg = DB_CONFIG.copy()
    if not cfg["password"]:
        import getpass
        cfg["password"] = getpass.getpass("Enter PostgreSQL password: ")
    return psycopg2.connect(**cfg)


def prompt_for_value(prompt_text, required, caster=str):
    """Prompt the user for a value, casting it to the correct Python type.
    Re-prompts on invalid input (bad int/float/bool/date) instead of crashing."""
    suffix = "" if required else " (press Enter to skip)"
    while True:
        val = input(f"  {prompt_text}{suffix}: ").strip()
        if val == "" and not required:
            return None
        if val == "" and required:
            print("    This field is required, please enter a value.")
            continue
        try:
            return caster(val)
        except (ValueError, TypeError):
            print(f"    Invalid value for this field, please try again.")


def insert_row(conn, table_def):
    print(f"\n--- Enter details for {table_def['label']} ---")
    columns = []
    values = []
    for col_name, prompt_text, required, caster in table_def["fields"]:
        val = prompt_for_value(prompt_text, required, caster)
        if val is not None:
            columns.append(col_name)
            values.append(val)

    if not columns:
        print("No data entered, skipping insert.")
        return

    query = sql.SQL("INSERT INTO {table} ({fields}) VALUES ({placeholders}) RETURNING *").format(
        table=sql.Identifier(table_def["name"]),
        fields=sql.SQL(", ").join(map(sql.Identifier, columns)),
        placeholders=sql.SQL(", ").join(sql.Placeholder() * len(columns)),
    )

    try:
        with conn.cursor() as cur:
            log_query(conn, cur, query, values, label=f"INSERT into {table_def['name']}")
            cur.execute(query, values)
            new_row = cur.fetchone()
            colnames = [desc[0] for desc in cur.description]
            conn.commit()
        print(f"\n  (Query logged to {QUERY_LOG_FILE})")
        print("\n  Row inserted successfully:")
        for name, val in zip(colnames, new_row):
            print(f"    {name}: {val}")
    except Exception as e:
        conn.rollback()
        print(f"\n  Insert failed: {e}")


def view_rows(conn, table_def):
    query = sql.SQL("SELECT * FROM {table} ORDER BY {pk}").format(
        table=sql.Identifier(table_def["name"]),
        pk=sql.Identifier(table_def["pk"]),
    )
    try:
        with conn.cursor() as cur:
            log_query(conn, cur, query, [], label=f"SELECT from {table_def['name']}")
            cur.execute(query)
            rows = cur.fetchall()
            colnames = [desc[0] for desc in cur.description]
    except Exception as e:
        conn.rollback()
        print(f"\n  Could not fetch rows: {e}")
        return

    print(f"\n--- {table_def['label']} ({len(rows)} rows) ---")
    if not rows:
        print("  (no rows yet)")
        return

    header = " | ".join(colnames)
    print(f"  {header}")
    print("  " + "-" * len(header))
    for row in rows:
        print("  " + " | ".join(str(v) for v in row))


def update_row(conn, table_def):
    view_rows(conn, table_def)
    pk = table_def["pk"]
    pk_val_raw = input(f"\n  Enter {pk} of the row to update (or 0 to cancel): ").strip()

    if pk_val_raw == "0" or pk_val_raw == "":
        print("  Cancelled.")
        return

    try:
        pk_val = int(pk_val_raw)
    except ValueError:
        print(f"  Invalid {pk}, must be a number.")
        return

    # Confirm the row exists first
    select_query = sql.SQL("SELECT * FROM {table} WHERE {pk} = %s").format(
        table=sql.Identifier(table_def["name"]),
        pk=sql.Identifier(pk),
    )
    try:
        with conn.cursor() as cur:
            cur.execute(select_query, (pk_val,))
            existing = cur.fetchone()
            colnames = [desc[0] for desc in cur.description]
    except Exception as e:
        conn.rollback()
        print(f"\n  Could not fetch row: {e}")
        return

    if not existing:
        print(f"\n  No row found with {pk} = {pk_val}.")
        return

    existing_map = dict(zip(colnames, existing))
    print(f"\n--- Update {table_def['label']} (leave blank to keep current value) ---")

    columns = []
    values = []
    for col_name, prompt_text, required, caster in table_def["fields"]:
        current_val = existing_map.get(col_name)
        raw = input(f"  {prompt_text} [current: {current_val}]: ").strip()
        if raw == "":
            continue
        try:
            val = caster(raw)
        except (ValueError, TypeError):
            print(f"    Invalid value, keeping current value for '{col_name}'.")
            continue
        columns.append(col_name)
        values.append(val)

    if not columns:
        print("  No changes entered, nothing updated.")
        return

    set_clause = sql.SQL(", ").join(
        sql.SQL("{} = {}").format(sql.Identifier(c), sql.Placeholder()) for c in columns
    )
    query = sql.SQL("UPDATE {table} SET {set_clause} WHERE {pk} = %s RETURNING *").format(
        table=sql.Identifier(table_def["name"]),
        set_clause=set_clause,
        pk=sql.Identifier(pk),
    )

    try:
        with conn.cursor() as cur:
            log_query(conn, cur, query, values + [pk_val], label=f"UPDATE {table_def['name']}")
            cur.execute(query, values + [pk_val])
            updated = cur.fetchone()
            colnames = [desc[0] for desc in cur.description]
            conn.commit()
        print(f"\n  (Query logged to {QUERY_LOG_FILE})")
        print("\n  Row updated successfully:")
        for name, val in zip(colnames, updated):
            print(f"    {name}: {val}")
    except Exception as e:
        conn.rollback()
        print(f"\n  Update failed: {e}")


def delete_row(conn, table_def):
    view_rows(conn, table_def)
    pk = table_def["pk"]
    pk_val_raw = input(f"\n  Enter {pk} of the row to delete (or 0 to cancel): ").strip()

    if pk_val_raw == "0" or pk_val_raw == "":
        print("  Cancelled.")
        return

    try:
        pk_val = int(pk_val_raw)
    except ValueError:
        print(f"  Invalid {pk}, must be a number.")
        return

    confirm = input(
        f"  Are you sure you want to delete {pk} = {pk_val}? "
        f"This may also delete related rows (y/n): "
    ).strip().lower()
    if confirm != "y":
        print("  Cancelled.")
        return

    query = sql.SQL("DELETE FROM {table} WHERE {pk} = %s RETURNING *").format(
        table=sql.Identifier(table_def["name"]),
        pk=sql.Identifier(pk),
    )

    try:
        with conn.cursor() as cur:
            log_query(conn, cur, query, (pk_val,), label=f"DELETE from {table_def['name']}")
            cur.execute(query, (pk_val,))
            deleted = cur.fetchone()
            conn.commit()
        print(f"\n  (Query logged to {QUERY_LOG_FILE})")
        if deleted:
            print(f"\n  Row with {pk} = {pk_val} deleted successfully.")
        else:
            print(f"\n  No row found with {pk} = {pk_val}.")
    except Exception as e:
        conn.rollback()
        print(f"\n  Delete failed: {e}")


def show_table_menu():
    print("\n===================================")
    print(" UrbanSync - Table Menu")
    print("===================================")
    for key, table_def in TABLES.items():
        print(f"  {key}. {table_def['label']}")
    print("  0. Exit")


def show_operation_menu(table_def):
    print(f"\n--- {table_def['label']}: choose an operation ---")
    print("  1. Insert a new row")
    print("  2. View all rows")
    print("  3. Update a row")
    print("  4. Delete a row")
    print("  0. Back to table menu")


def main():
    print("Connecting to UrbanSync database...")
    try:
        conn = connect()
    except Exception as e:
        print(f"Could not connect to the database: {e}")
        return
    print("Connected successfully.\n")

    try:
        while True:
            show_table_menu()
            choice = input("\nSelect a table: ").strip()

            if choice == "0":
                print("Exiting. Goodbye!")
                break

            table_def = TABLES.get(choice)
            if not table_def:
                print("Invalid choice, please select a valid option.")
                continue

            while True:
                show_operation_menu(table_def)
                op = input("\nChoose an operation: ").strip()

                if op == "0":
                    break
                elif op == "1":
                    insert_row(conn, table_def)
                elif op == "2":
                    view_rows(conn, table_def)
                elif op == "3":
                    update_row(conn, table_def)
                elif op == "4":
                    delete_row(conn, table_def)
                else:
                    print("Invalid choice, please select a valid option.")
    finally:
        conn.close()


if __name__ == "__main__":
    main()