-- [2026-08-17 11:09:05] INSERT into intersections
INSERT INTO "intersections" ("intersection_name", "road_id", "has_signal") VALUES ('msk', 12, true) RETURNING *;

-- [2026-08-17 11:36:40] INSERT into roads
INSERT INTO "roads" ("road_name", "length_km", "num_lanes", "zone") VALUES ('KSG', 6.9, 5, 'NORTH') RETURNING *;

-- [2026-08-17 11:36:46] SELECT from roads
SELECT * FROM "roads" ORDER BY "road_id";

-- [2026-08-17 11:37:14] INSERT into parkinglots
INSERT INTO "parkinglots" ("lot_name", "zone", "total_slots", "available_slots") VALUES ('KSN', '3', 90, 43) RETURNING *;

-- [2026-08-17 11:37:21] SELECT from parkinglots
SELECT * FROM "parkinglots" ORDER BY "lot_id";

-- [2026-08-17 11:38:00] INSERT into sensors
INSERT INTO "sensors" ("sensor_type", "road_id", "status") VALUES ('Traffic camera', 1, 'active') RETURNING *;

-- [2026-08-17 11:38:50] INSERT into sensors
INSERT INTO "sensors" ("sensor_type", "road_id", "status") VALUES ('Traffic camera', 1, 'Active') RETURNING *;

-- [2026-08-17 11:39:49] INSERT into trafficsignals
INSERT INTO "trafficsignals" ("intersection_id", "signal_status", "last_maintained") VALUES (1, 'Working', '2026-01-29'::date) RETURNING *;

-- [2026-08-17 11:40:04] SELECT from trafficsignals
SELECT * FROM "trafficsignals" ORDER BY "signal_id";

-- [2026-08-17 11:40:14] SELECT from intersections
SELECT * FROM "intersections" ORDER BY "intersection_id";

-- [2026-08-17 11:40:34] INSERT into intersections
INSERT INTO "intersections" ("intersection_name", "road_id", "has_signal") VALUES ('KDM', 1, true) RETURNING *;

-- [2026-08-17 11:41:05] INSERT into trafficsignals
INSERT INTO "trafficsignals" ("intersection_id", "signal_status", "last_maintained") VALUES (3, 'Working', '2007-01-29'::date) RETURNING *;

-- [2026-08-17 11:41:36] INSERT into vehicles
INSERT INTO "vehicles" ("plate_number", "vehicle_type", "owner_name") VALUES ('AP 09 789', 'Bike', 'Diya') RETURNING *;

-- [2026-08-17 11:42:06] INSERT into trafficincidents
INSERT INTO "trafficincidents" ("road_id", "incident_type", "severity", "status") VALUES (1, 'Accident', 'Low', 'Reported') RETURNING *;

-- [2026-08-17 11:42:42] INSERT into maintenancerequests
INSERT INTO "maintenancerequests" ("asset_type", "description", "status") VALUES ('Road', 'Pathole', 'Pending') RETURNING *;

-- [2026-08-17 15:31:47] SELECT from roads
SELECT * FROM "roads" ORDER BY "road_id";

-- [2026-08-17 15:31:57] SELECT from roads
SELECT * FROM "roads" ORDER BY "road_id";

-- [2026-08-17 15:33:05] UPDATE roads
UPDATE "roads" SET "road_name" = 'HM', "length_km" = 7.8, "num_lanes" = 8, "zone" = 'East' WHERE "road_id" = 1 RETURNING *;

-- [2026-08-17 15:33:30] SELECT from trafficincidents
SELECT * FROM "trafficincidents" ORDER BY "incident_id";

-- [2026-08-17 15:34:30] INSERT into trafficincidents
INSERT INTO "trafficincidents" ("road_id", "incident_type", "severity", "status") VALUES (3, 'Pothole', 'High', 'In Progress') RETURNING *;

-- [2026-08-17 16:43:15] INSERT into roads
INSERT INTO "roads" ("road_name", "length_km", "num_lanes", "zone") VALUES ('gm', 4.8, 3, 'Central') RETURNING *;

-- [2026-08-17 23:21:00] INSERT into trafficincidents
INSERT INTO "trafficincidents" ("road_id", "incident_type", "severity", "status") VALUES (1, 'Pothole', 'Low', 'Reported') RETURNING *;

-- [2026-08-17 23:21:20] INSERT into maintenancerequests
INSERT INTO "maintenancerequests" ("asset_type") VALUES ('sensor') RETURNING *;

-- [2026-08-17 23:22:02] INSERT into parkinglots
INSERT INTO "parkinglots" ("lot_name", "total_slots", "available_slots") VALUES ('hm', 8, 7) RETURNING *;

-- [2026-08-17 23:22:16] INSERT into parkinglots
INSERT INTO "parkinglots" ("lot_name", "zone", "total_slots", "available_slots") VALUES ('iu', '6', 4, 7) RETURNING *;

-- [2026-08-17 23:43:10] INSERT into vehicles
INSERT INTO "vehicles" ("plate_number", "vehicle_type", "owner_name") VALUES ('AP 98 567', 'car', 'kkk') RETURNING *;

-- [2026-08-18 09:10:29] INSERT into roads
INSERT INTO "roads" ("road_name", "length_km", "num_lanes", "zone") VALUES ('gh', 5.6, 8, 'East') RETURNING *;

-- [2026-08-18 09:10:35] SELECT from roads
SELECT * FROM "roads" ORDER BY "road_id";

-- [2026-08-18 09:11:24] INSERT into roads
INSERT INTO "roads" ("road_name", "length_km", "num_lanes") VALUES ('yy', 77.0, 55) RETURNING *;

