-- =====================================================================
-- UrbanSync - Advanced SQL Queries (23AIE303 DBMS)
-- Each query shows: multi-table JOINs, subqueries, GROUP BY / HAVING,
-- aggregate functions. Purpose is stated above each one.
-- Run in pgAdmin Query Tool against the URBANSYNC database.
-- =====================================================================

-- Q1. Incidents per road (3-table style report: roads + incidents)
-- Purpose: find the most accident-prone roads; LEFT JOIN keeps roads with 0 incidents.
SELECT r.road_id, r.road_name, r.zone,
       COUNT(ti.incident_id)                                  AS total_incidents,
       COUNT(*) FILTER (WHERE ti.severity = 'High')           AS high_severity
FROM roads r
LEFT JOIN trafficincidents ti ON ti.road_id = r.road_id
GROUP BY r.road_id, r.road_name, r.zone
ORDER BY total_incidents DESC, r.road_name;

-- Q2. Zone-wise infrastructure summary (JOIN + GROUP BY + aggregates)
-- Purpose: compare zones by number of roads, total road length and average lanes.
SELECT zone,
       COUNT(*)                    AS num_roads,
       ROUND(SUM(length_km)::numeric, 2) AS total_length_km,
       ROUND(AVG(num_lanes), 1)    AS avg_lanes
FROM roads
WHERE zone IS NOT NULL
GROUP BY zone
ORDER BY total_length_km DESC;

-- Q3. Signalised intersections whose signal is not working (3-table JOIN)
-- Purpose: give maintenance teams a list of faulty signals with their road.
SELECT i.intersection_name, r.road_name, r.zone,
       ts.signal_status, ts.last_maintained
FROM trafficsignals ts
JOIN intersections i ON i.intersection_id = ts.intersection_id
JOIN roads r         ON r.road_id = i.road_id
WHERE ts.signal_status <> 'Working'
ORDER BY ts.last_maintained NULLS FIRST;

-- Q4. Roads with NO sensors installed (subquery with NOT EXISTS)
-- Purpose: identify monitoring blind spots.
SELECT r.road_id, r.road_name, r.zone
FROM roads r
WHERE NOT EXISTS (SELECT 1 FROM sensors s WHERE s.road_id = r.road_id)
ORDER BY r.road_id;

-- Q5. Roads with more incidents than the average road (subquery in HAVING)
-- Purpose: flag above-average problem roads.
SELECT r.road_name, COUNT(ti.incident_id) AS incidents
FROM roads r
JOIN trafficincidents ti ON ti.road_id = r.road_id
GROUP BY r.road_name
HAVING COUNT(ti.incident_id) > (
    SELECT AVG(cnt) FROM (
        SELECT COUNT(*) AS cnt FROM trafficincidents GROUP BY road_id
    ) per_road
)
ORDER BY incidents DESC;

-- Q6. Parking occupancy per zone (aggregate + calculated column)
-- Purpose: show which zones are close to full so drivers can be redirected.
SELECT zone,
       SUM(total_slots)                         AS total_slots,
       SUM(available_slots)                     AS available_slots,
       ROUND(100.0 * (SUM(total_slots) - SUM(available_slots))
             / NULLIF(SUM(total_slots), 0), 1)  AS occupancy_pct
FROM parkinglots
GROUP BY zone
ORDER BY occupancy_pct DESC;

-- Q7. Sensor health per road (JOIN + conditional aggregation + HAVING)
-- Purpose: roads where at least one sensor is faulty or inactive.
SELECT r.road_name,
       COUNT(s.sensor_id)                                    AS total_sensors,
       COUNT(*) FILTER (WHERE s.status = 'Active')           AS active,
       COUNT(*) FILTER (WHERE s.status IN ('Faulty','Inactive')) AS needs_attention
FROM roads r
JOIN sensors s ON s.road_id = r.road_id
GROUP BY r.road_name
HAVING COUNT(*) FILTER (WHERE s.status IN ('Faulty','Inactive')) > 0
ORDER BY needs_attention DESC;

-- Q8. Open maintenance workload by asset type (GROUP BY + aggregate)
-- Purpose: see which asset type has the most unfinished maintenance requests.
SELECT asset_type,
       COUNT(*) FILTER (WHERE status = 'Pending')      AS pending,
       COUNT(*) FILTER (WHERE status = 'In Progress')  AS in_progress,
       COUNT(*) FILTER (WHERE status = 'Completed')    AS completed
FROM maintenancerequests
GROUP BY asset_type
ORDER BY pending DESC;

-- Q9. Pending signal maintenance requests with signal details (JOIN on polymorphic key)
-- Purpose: link maintenance requests (asset_type='TrafficSignal') to the actual signal,
--          its intersection and road.
SELECT mr.request_id, mr.description, mr.status,
       ts.signal_status, i.intersection_name, r.road_name
FROM maintenancerequests mr
JOIN trafficsignals ts ON mr.asset_type = 'TrafficSignal' AND mr.asset_id = ts.signal_id
JOIN intersections i   ON i.intersection_id = ts.intersection_id
JOIN roads r           ON r.road_id = i.road_id
WHERE mr.status <> 'Completed';

-- Q10. Top road per zone by incident count (correlated subquery)
-- Purpose: worst road in each zone.
SELECT r.zone, r.road_name,
       (SELECT COUNT(*) FROM trafficincidents ti WHERE ti.road_id = r.road_id) AS incidents
FROM roads r
WHERE (SELECT COUNT(*) FROM trafficincidents ti WHERE ti.road_id = r.road_id) =
      (SELECT MAX(c) FROM (
           SELECT COUNT(*) AS c
           FROM roads r2 LEFT JOIN trafficincidents t2 ON t2.road_id = r2.road_id
           WHERE r2.zone = r.zone GROUP BY r2.road_id) x)
ORDER BY r.zone;
