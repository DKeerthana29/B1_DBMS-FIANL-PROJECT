--
-- PostgreSQL database dump
--

\restrict UKJdqINeUWGU7RWLFwIp1dlsB27SxV9KN1MziBqaoDUjrgnwl1elQWifygw7L8m

-- Dumped from database version 18.4
-- Dumped by pg_dump version 18.4

-- Started on 2026-10-16 20:36:36

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 237 (class 1255 OID 32934)
-- Name: trg_sensor_faulty_maintenance(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.trg_sensor_faulty_maintenance() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Only fire when status is (now) 'Faulty' AND it wasn't
    -- already 'Faulty' before this change (avoids duplicate
    -- requests every time the row is touched while still faulty)
    IF NEW.status = 'Faulty'
       AND (TG_OP = 'INSERT' OR OLD.status IS DISTINCT FROM 'Faulty') THEN

        INSERT INTO maintenancerequests (asset_type, asset_id, description, status)
        VALUES (
            'Sensor',
            NEW.sensor_id,
            'Auto-generated: sensor ' || NEW.sensor_id || ' (' ||
                COALESCE(NEW.sensor_type, 'unknown type') || ') reported Faulty',
            'Pending'
        );
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.trg_sensor_faulty_maintenance() OWNER TO postgres;

--
-- TOC entry 242 (class 1255 OID 32936)
-- Name: trg_signal_faulty_maintenance(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.trg_signal_faulty_maintenance() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NEW.signal_status = 'Faulty'
       AND (TG_OP = 'INSERT' OR OLD.signal_status IS DISTINCT FROM 'Faulty') THEN

        INSERT INTO maintenancerequests (asset_type, asset_id, description, status)
        VALUES (
            'TrafficSignal',
            NEW.signal_id,
            'Auto-generated: traffic signal ' || NEW.signal_id ||
                ' at intersection ' || COALESCE(NEW.intersection_id::text, 'unknown') ||
                ' reported Faulty',
            'Pending'
        );
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.trg_signal_faulty_maintenance() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 222 (class 1259 OID 32779)
-- Name: intersections; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.intersections (
    intersection_id integer NOT NULL,
    intersection_name character varying(100) NOT NULL,
    road_id integer,
    has_signal boolean DEFAULT false
);


ALTER TABLE public.intersections OWNER TO postgres;

--
-- TOC entry 221 (class 1259 OID 32778)
-- Name: intersections_intersection_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.intersections_intersection_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.intersections_intersection_id_seq OWNER TO postgres;

--
-- TOC entry 5099 (class 0 OID 0)
-- Dependencies: 221
-- Name: intersections_intersection_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.intersections_intersection_id_seq OWNED BY public.intersections.intersection_id;


--
-- TOC entry 234 (class 1259 OID 32860)
-- Name: maintenancerequests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.maintenancerequests (
    request_id integer NOT NULL,
    asset_type character varying(50),
    asset_id integer,
    description text,
    status character varying(20),
    requested_date date DEFAULT CURRENT_DATE,
    CONSTRAINT maintenancerequests_status_check CHECK (((status)::text = ANY ((ARRAY['Pending'::character varying, 'In Progress'::character varying, 'Completed'::character varying])::text[])))
);


ALTER TABLE public.maintenancerequests OWNER TO postgres;

--
-- TOC entry 233 (class 1259 OID 32859)
-- Name: maintenancerequests_request_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.maintenancerequests_request_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.maintenancerequests_request_id_seq OWNER TO postgres;

--
-- TOC entry 5100 (class 0 OID 0)
-- Dependencies: 233
-- Name: maintenancerequests_request_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.maintenancerequests_request_id_seq OWNED BY public.maintenancerequests.request_id;


--
-- TOC entry 226 (class 1259 OID 32808)
-- Name: parkinglots; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.parkinglots (
    lot_id integer NOT NULL,
    lot_name character varying(100) NOT NULL,
    zone character varying(50),
    total_slots integer NOT NULL,
    available_slots integer NOT NULL,
    CONSTRAINT chk_parking_slots CHECK ((available_slots <= total_slots)),
    CONSTRAINT parkinglots_zone_check CHECK (((zone)::text = ANY ((ARRAY['Central'::character varying, 'North'::character varying, 'South'::character varying, 'East'::character varying, 'West'::character varying])::text[])))
);


ALTER TABLE public.parkinglots OWNER TO postgres;

--
-- TOC entry 225 (class 1259 OID 32807)
-- Name: parkinglots_lot_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.parkinglots_lot_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.parkinglots_lot_id_seq OWNER TO postgres;

--
-- TOC entry 5101 (class 0 OID 0)
-- Dependencies: 225
-- Name: parkinglots_lot_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.parkinglots_lot_id_seq OWNED BY public.parkinglots.lot_id;


--
-- TOC entry 220 (class 1259 OID 32770)
-- Name: roads; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roads (
    road_id integer NOT NULL,
    road_name character varying(100) NOT NULL,
    length_km numeric(6,2),
    num_lanes integer,
    zone character varying(50),
    latitude numeric(9,6),
    longitude numeric(9,6)
);


ALTER TABLE public.roads OWNER TO postgres;

--
-- TOC entry 219 (class 1259 OID 32769)
-- Name: roads_road_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.roads_road_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.roads_road_id_seq OWNER TO postgres;

--
-- TOC entry 5102 (class 0 OID 0)
-- Dependencies: 219
-- Name: roads_road_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.roads_road_id_seq OWNED BY public.roads.road_id;


--
-- TOC entry 228 (class 1259 OID 32819)
-- Name: sensors; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sensors (
    sensor_id integer NOT NULL,
    sensor_type character varying(50),
    road_id integer,
    status character varying(20),
    CONSTRAINT sensors_status_check CHECK (((status)::text = ANY ((ARRAY['Active'::character varying, 'Inactive'::character varying, 'Faulty'::character varying])::text[])))
);


ALTER TABLE public.sensors OWNER TO postgres;

--
-- TOC entry 227 (class 1259 OID 32818)
-- Name: sensors_sensor_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sensors_sensor_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sensors_sensor_id_seq OWNER TO postgres;

--
-- TOC entry 5103 (class 0 OID 0)
-- Dependencies: 227
-- Name: sensors_sensor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sensors_sensor_id_seq OWNED BY public.sensors.sensor_id;


--
-- TOC entry 232 (class 1259 OID 32844)
-- Name: trafficincidents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.trafficincidents (
    incident_id integer NOT NULL,
    road_id integer,
    incident_type character varying(50),
    severity character varying(20),
    reported_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    status character varying(20),
    CONSTRAINT trafficincidents_severity_check CHECK (((severity)::text = ANY ((ARRAY['Low'::character varying, 'Medium'::character varying, 'High'::character varying])::text[]))),
    CONSTRAINT trafficincidents_status_check CHECK (((status)::text = ANY ((ARRAY['Reported'::character varying, 'In Progress'::character varying, 'Resolved'::character varying])::text[])))
);


ALTER TABLE public.trafficincidents OWNER TO postgres;

--
-- TOC entry 231 (class 1259 OID 32843)
-- Name: trafficincidents_incident_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.trafficincidents_incident_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.trafficincidents_incident_id_seq OWNER TO postgres;

--
-- TOC entry 5104 (class 0 OID 0)
-- Dependencies: 231
-- Name: trafficincidents_incident_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.trafficincidents_incident_id_seq OWNED BY public.trafficincidents.incident_id;


--
-- TOC entry 224 (class 1259 OID 32794)
-- Name: trafficsignals; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.trafficsignals (
    signal_id integer NOT NULL,
    intersection_id integer,
    signal_status character varying(20),
    last_maintained date,
    CONSTRAINT trafficsignals_signal_status_check CHECK (((signal_status)::text = ANY ((ARRAY['Working'::character varying, 'Faulty'::character varying, 'Under Maintenance'::character varying])::text[])))
);


ALTER TABLE public.trafficsignals OWNER TO postgres;

--
-- TOC entry 223 (class 1259 OID 32793)
-- Name: trafficsignals_signal_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.trafficsignals_signal_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.trafficsignals_signal_id_seq OWNER TO postgres;

--
-- TOC entry 5105 (class 0 OID 0)
-- Dependencies: 223
-- Name: trafficsignals_signal_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.trafficsignals_signal_id_seq OWNED BY public.trafficsignals.signal_id;


--
-- TOC entry 236 (class 1259 OID 32945)
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    user_id integer NOT NULL,
    username character varying(50) NOT NULL,
    password_hash character varying(255) NOT NULL,
    role character varying(20) NOT NULL,
    CONSTRAINT users_role_check CHECK (((role)::text = ANY ((ARRAY['admin'::character varying, 'viewer'::character varying])::text[])))
);


ALTER TABLE public.users OWNER TO postgres;

--
-- TOC entry 235 (class 1259 OID 32944)
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_user_id_seq OWNER TO postgres;

--
-- TOC entry 5106 (class 0 OID 0)
-- Dependencies: 235
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_user_id_seq OWNED BY public.users.user_id;


--
-- TOC entry 230 (class 1259 OID 32833)
-- Name: vehicles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vehicles (
    vehicle_id integer NOT NULL,
    plate_number character varying(20) NOT NULL,
    vehicle_type character varying(30),
    owner_name character varying(100),
    CONSTRAINT vehicles_type_check CHECK ((upper(TRIM(BOTH FROM vehicle_type)) = ANY (ARRAY['BIKE'::text, 'CAR'::text])))
);


ALTER TABLE public.vehicles OWNER TO postgres;

--
-- TOC entry 229 (class 1259 OID 32832)
-- Name: vehicles_vehicle_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.vehicles_vehicle_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.vehicles_vehicle_id_seq OWNER TO postgres;

--
-- TOC entry 5107 (class 0 OID 0)
-- Dependencies: 229
-- Name: vehicles_vehicle_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.vehicles_vehicle_id_seq OWNED BY public.vehicles.vehicle_id;


--
-- TOC entry 4899 (class 2604 OID 32782)
-- Name: intersections intersection_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.intersections ALTER COLUMN intersection_id SET DEFAULT nextval('public.intersections_intersection_id_seq'::regclass);


--
-- TOC entry 4907 (class 2604 OID 32863)
-- Name: maintenancerequests request_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.maintenancerequests ALTER COLUMN request_id SET DEFAULT nextval('public.maintenancerequests_request_id_seq'::regclass);


--
-- TOC entry 4902 (class 2604 OID 32811)
-- Name: parkinglots lot_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parkinglots ALTER COLUMN lot_id SET DEFAULT nextval('public.parkinglots_lot_id_seq'::regclass);


--
-- TOC entry 4898 (class 2604 OID 32773)
-- Name: roads road_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roads ALTER COLUMN road_id SET DEFAULT nextval('public.roads_road_id_seq'::regclass);


--
-- TOC entry 4903 (class 2604 OID 32822)
-- Name: sensors sensor_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sensors ALTER COLUMN sensor_id SET DEFAULT nextval('public.sensors_sensor_id_seq'::regclass);


--
-- TOC entry 4905 (class 2604 OID 32847)
-- Name: trafficincidents incident_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trafficincidents ALTER COLUMN incident_id SET DEFAULT nextval('public.trafficincidents_incident_id_seq'::regclass);


--
-- TOC entry 4901 (class 2604 OID 32797)
-- Name: trafficsignals signal_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trafficsignals ALTER COLUMN signal_id SET DEFAULT nextval('public.trafficsignals_signal_id_seq'::regclass);


--
-- TOC entry 4909 (class 2604 OID 32948)
-- Name: users user_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN user_id SET DEFAULT nextval('public.users_user_id_seq'::regclass);


--
-- TOC entry 4904 (class 2604 OID 32836)
-- Name: vehicles vehicle_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vehicles ALTER COLUMN vehicle_id SET DEFAULT nextval('public.vehicles_vehicle_id_seq'::regclass);


--
-- TOC entry 4922 (class 2606 OID 32787)
-- Name: intersections intersections_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.intersections
    ADD CONSTRAINT intersections_pkey PRIMARY KEY (intersection_id);


--
-- TOC entry 4936 (class 2606 OID 32870)
-- Name: maintenancerequests maintenancerequests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.maintenancerequests
    ADD CONSTRAINT maintenancerequests_pkey PRIMARY KEY (request_id);


--
-- TOC entry 4926 (class 2606 OID 32817)
-- Name: parkinglots parkinglots_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parkinglots
    ADD CONSTRAINT parkinglots_pkey PRIMARY KEY (lot_id);


--
-- TOC entry 4920 (class 2606 OID 32777)
-- Name: roads roads_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roads
    ADD CONSTRAINT roads_pkey PRIMARY KEY (road_id);


--
-- TOC entry 4928 (class 2606 OID 32826)
-- Name: sensors sensors_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sensors
    ADD CONSTRAINT sensors_pkey PRIMARY KEY (sensor_id);


--
-- TOC entry 4934 (class 2606 OID 32853)
-- Name: trafficincidents trafficincidents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trafficincidents
    ADD CONSTRAINT trafficincidents_pkey PRIMARY KEY (incident_id);


--
-- TOC entry 4924 (class 2606 OID 32801)
-- Name: trafficsignals trafficsignals_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trafficsignals
    ADD CONSTRAINT trafficsignals_pkey PRIMARY KEY (signal_id);


--
-- TOC entry 4938 (class 2606 OID 32955)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- TOC entry 4940 (class 2606 OID 32957)
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- TOC entry 4930 (class 2606 OID 32840)
-- Name: vehicles vehicles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vehicles
    ADD CONSTRAINT vehicles_pkey PRIMARY KEY (vehicle_id);


--
-- TOC entry 4932 (class 2606 OID 32842)
-- Name: vehicles vehicles_plate_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vehicles
    ADD CONSTRAINT vehicles_plate_number_key UNIQUE (plate_number);


--
-- TOC entry 4946 (class 2620 OID 32978)
-- Name: sensors sensor_faulty_trigger; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER sensor_faulty_trigger AFTER INSERT OR UPDATE ON public.sensors FOR EACH ROW EXECUTE FUNCTION public.trg_sensor_faulty_maintenance();


--
-- TOC entry 4945 (class 2620 OID 32979)
-- Name: trafficsignals signal_faulty_trigger; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER signal_faulty_trigger AFTER INSERT OR UPDATE ON public.trafficsignals FOR EACH ROW EXECUTE FUNCTION public.trg_signal_faulty_maintenance();


--
-- TOC entry 4941 (class 2606 OID 32958)
-- Name: intersections fk_intersections_road; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.intersections
    ADD CONSTRAINT fk_intersections_road FOREIGN KEY (road_id) REFERENCES public.roads(road_id) ON DELETE CASCADE;


--
-- TOC entry 4943 (class 2606 OID 32963)
-- Name: sensors fk_sensors_road; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sensors
    ADD CONSTRAINT fk_sensors_road FOREIGN KEY (road_id) REFERENCES public.roads(road_id) ON DELETE CASCADE;


--
-- TOC entry 4944 (class 2606 OID 32968)
-- Name: trafficincidents fk_trafficincidents_road; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trafficincidents
    ADD CONSTRAINT fk_trafficincidents_road FOREIGN KEY (road_id) REFERENCES public.roads(road_id) ON DELETE CASCADE;


--
-- TOC entry 4942 (class 2606 OID 32973)
-- Name: trafficsignals fk_trafficsignals_intersection; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trafficsignals
    ADD CONSTRAINT fk_trafficsignals_intersection FOREIGN KEY (intersection_id) REFERENCES public.intersections(intersection_id) ON DELETE CASCADE;


-- Completed on 2026-10-16 20:36:36

--
-- PostgreSQL database dump complete
--

\unrestrict UKJdqINeUWGU7RWLFwIp1dlsB27SxV9KN1MziBqaoDUjrgnwl1elQWifygw7L8m

