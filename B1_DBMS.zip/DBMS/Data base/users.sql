CREATE SEQUENCE IF NOT EXISTS public.users_user_id_seq
START WITH 1
INCREMENT BY 1
CACHE 1;

CREATE TABLE IF NOT EXISTS public.users (
user_id INTEGER NOT NULL DEFAULT nextval('public.users_user_id_seq'::regclass),
username VARCHAR(50) NOT NULL,
password_hash VARCHAR(255) NOT NULL,
role VARCHAR(20) NOT NULL,
CONSTRAINT users_pkey PRIMARY KEY (user_id),
CONSTRAINT users_username_key UNIQUE (username),
CONSTRAINT users_role_check CHECK (role IN ('admin', 'viewer'))
);

ALTER SEQUENCE public.users_user_id_seq
OWNED BY public.users.user_id;
