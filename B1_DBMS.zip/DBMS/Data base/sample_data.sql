
INSERT INTO public.roads
    (road_name, length_km, num_lanes, zone, latitude, longitude)
VALUES
    ('Main Road', 5.50, 4, 'Central', 10.123456, 76.123456),
    ('Park Road', 3.20, 2, 'North', 10.234567, 76.234567);

INSERT INTO public.intersections
    (intersection_name, road_id, has_signal)
VALUES
    ('Main Junction', 1, TRUE),
    ('Park Junction', 2, FALSE);

INSERT INTO public.parkinglots
    (lot_name, zone, total_slots, available_slots)
VALUES
    ('Central Parking', 'Central', 100, 75),
    ('North Parking', 'North', 50, 30);

INSERT INTO public.sensors
    (sensor_type, road_id, status)
VALUES
    ('Traffic Sensor', 1, 'Active'),
    ('Air Quality Sensor', 2, 'Inactive');

INSERT INTO public.trafficincidents
    (road_id, incident_type, severity, status)
VALUES
    (1, 'Accident', 'High', 'Reported'),
    (2, 'Traffic Congestion', 'Medium', 'In Progress');

INSERT INTO public.trafficsignals
    (intersection_id, signal_status, last_maintained)
VALUES
    (1, 'Working', CURRENT_DATE),
    (2, 'Under Maintenance', CURRENT_DATE);

INSERT INTO public.vehicles
    (plate_number, vehicle_type, owner_name)
VALUES
    ('SAMPLE-001', 'CAR', 'Sample Owner One'),
    ('SAMPLE-002', 'BIKE', 'Sample Owner Two');

INSERT INTO public.maintenancerequests
    (asset_type, asset_id, description, status)
VALUES
    ('Sensor', 1, 'Routine sensor inspection', 'Pending'),
    ('TrafficSignal', 2, 'Signal maintenance required', 'In Progress');