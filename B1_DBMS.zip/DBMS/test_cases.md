# UrbanSync - Test Cases and Validation

| # | Area | Action | Expected result |
|---|------|--------|-----------------|
| 1 | Login | Log in as `admin` / `admin123` | Redirected to dashboard, role = admin |
| 2 | Login | Log in with wrong password | "Invalid username or password." (401) |
| 3 | Access | Open `/` without logging in | Redirect to `/login` |
| 4 | Access | Call `/api/tables/roads/rows` without login | 401 JSON `Not logged in` |
| 5 | Roles | Log in as `viewer`, try to insert a road | 403 `Admin access required` |
| 6 | Roles | Log in as `viewer`, view any table | Rows shown, no error |
| 7 | Insert | Admin adds a road (name, 3.5 km, 2 lanes, Central) | New row returned and shown in table |
| 8 | Validation | Insert a road with empty name | 400 `Road name is required.` |
| 9 | Constraint (FK) | Insert intersection with non-existent `road_id` | Error, nothing inserted |
| 10 | Constraint (UNIQUE) | Insert vehicle with an existing plate number | Error, nothing inserted |
| 11 | Update | Admin edits a parking lot's available slots | Row updated, new values returned |
| 12 | Update | Update a non-existent id (e.g. 9999) | 404 `No row found` |
| 13 | Delete | Admin deletes a road that has intersections | Row removed; dependent rows follow the ON DELETE rule in the DDL |
| 14 | Security | Enter `'; DROP TABLE roads;--` as a road name | Stored as plain text, table intact (parameterized query) |
| 15 | Unknown table | GET `/api/tables/foo/rows` | 404 `Unknown table` |
| 16 | Pooling | Reload a table page 20 times quickly | No connection errors, pool reuses connections |
| 17 | Logging | Perform any insert/update/delete | Matching SQL line appended to `urbansync_query_log.sql` |
| 18 | Advanced SQL | Run `database/advanced_queries.sql` in pgAdmin | All 10 queries return results with no errors |

Record Actual Result / Pass-Fail and a screenshot next to each row before submission.
